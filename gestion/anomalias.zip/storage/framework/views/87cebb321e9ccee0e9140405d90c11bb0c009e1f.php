<?php $__env->startSection('titulo','Formato-11'); ?>

<?php $__env->startSection('contenido1'); ?>

FORMATO DE CONTROL DE LIMPIEZA Y DESINFECCION EL GUALILO FREE ZONE

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido2'); ?>

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSf5sBnpHgtlzi1JtW98lydJqGuct1EQpArKlsiYKj2Ci6Cilw/viewform" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>