<?php $__env->startSection('titulo','Formato-6'); ?>

<?php $__env->startSection('contenido1'); ?>

CONTROL DE PRODUCTO NO CONFORME

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido2'); ?>

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeNnlcGy2r_xSZnpH8_57Adtyzkt5RBILOQq0PX7QNeXcl2Dg/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>