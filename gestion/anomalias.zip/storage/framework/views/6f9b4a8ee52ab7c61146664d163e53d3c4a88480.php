<?php $__env->startSection('titulo','Formato-12'); ?>

<?php $__env->startSection('contenido1'); ?>

CONTROL DE DOSIFICACIÓN DE PRODUCTOS DE LIMPIEZA Y DESIFECCIÓN EL GUALILO FREE ZONE

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido2'); ?>

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLScnBJWGv4nBBSAGdAcsLetf5XDyftsp1XmZPFnfBye9DjAmxA/viewform" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>