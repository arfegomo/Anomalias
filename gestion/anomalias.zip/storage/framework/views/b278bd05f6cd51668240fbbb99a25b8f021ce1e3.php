<?php $__env->startSection('titulo','Registro personas terraza café'); ?>

<?php $__env->startSection('contenido1'); ?>

REGISTRO DE PERSONAS TERRAZA CAFÉ

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido2'); ?>

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSd9ycPDg50QKXPpZi_2WmNk7fgnet8Fn-veYsbzxkBl5fqSXQ/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
             
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>