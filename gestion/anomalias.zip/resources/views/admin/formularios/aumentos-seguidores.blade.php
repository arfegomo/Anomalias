@extends('master')

@section('titulo','Aumento Seguidores')

@section('contenido1')

Campaña Aumento de Seguidores

@endsection

@section('contenido2')




<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeNDCZBFoEhUo9pV2QklNP6BUNzbjy2BcH4rQrS9aa_p2qU5Q/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>




@endsection
