@extends('master')

@section('titulo','Registro personas terraza café')

@section('contenido1')

REGISTRO DE PERSONAS TERRAZA CAFÉ

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSd9ycPDg50QKXPpZi_2WmNk7fgnet8Fn-veYsbzxkBl5fqSXQ/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
             
@endsection

