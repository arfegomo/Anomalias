@extends('master')

@section('titulo','Formato-3')

@section('contenido1')

FORMATO DE CONTROL DE TEMPERATURA DE REFRIGERACIÓN DE NEVERA

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSfLITF0295zyGVWjLOrR_yOifZbai7Qo2P6wOtj4sZ8bzKWaw/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection



