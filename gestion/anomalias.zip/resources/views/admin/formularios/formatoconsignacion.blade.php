@extends('master')

@section('titulo','Formato de consignación')

@section('contenido1')

REGISTRO DIARIO DE CONSIGNACIONES

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/137ctsxCVSrkNwejIhgukHwqs_Rw1RnKi4ZroiX9hYSU/viewform?embedded=true" width="640" height="1189" frameborder="0" marginheight="0" marginwidth="0">Cargando…


</iframe>

@endsection



