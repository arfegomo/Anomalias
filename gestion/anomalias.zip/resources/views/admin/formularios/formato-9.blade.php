@extends('master')

@section('titulo','Formato-9')

@section('contenido1')

CONTROL DE SELLOS

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSebnwACONcSBmQ7B5yZy38sBrx5JnzWV5TjnR3eoK1KVR8aTw/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection
