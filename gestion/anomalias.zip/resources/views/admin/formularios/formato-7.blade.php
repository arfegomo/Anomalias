@extends('master')

@section('titulo','Formato-7')

@section('contenido1')

CONTROL DE DOSIFICACIÓN DE PRODUCTOS DE LIMPIEZA Y DESIFECCIÓN

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSckYxIwmiqk4WoXxs2HX75VaVBmFQwO6VM6gOI0BIDyVjgtWw/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection
