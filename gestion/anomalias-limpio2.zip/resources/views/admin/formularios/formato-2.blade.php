@extends('master')

@section('titulo','Formato-2')

@section('contenido1')

FORMATO DE CONTROL DE TEMPERATURA DE REFRIGERACIÓN DE VITRINA EXHIBIDORA

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdEEuiXxA9_5rPjWFSz2gkCoB1o30RNVxxq6Xs6xDSPIzLbvw/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection



