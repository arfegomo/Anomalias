@extends('master')

@section('titulo','Formato de consignación')

@section('contenido1')

REGISTRO DIARIO DE CONSIGNACIONES

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSd--Q2EnSU4k-JjpdYdf_WI1bjbrJtgbXrGC14eMGBCKwu1nA/viewform?embedded=true" width="640" height="1189" frameborder="0" marginheight="0" marginwidth="0">Cargando…
</iframe>

@endsection



