@extends('master')

@section('titulo','Formato-6')

@section('contenido1')

CONTROL DE PRODUCTO NO CONFORME

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeNnlcGy2r_xSZnpH8_57Adtyzkt5RBILOQq0PX7QNeXcl2Dg/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection
