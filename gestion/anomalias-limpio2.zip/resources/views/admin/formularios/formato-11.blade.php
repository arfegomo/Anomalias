@extends('master')

@section('titulo','Formato-11')

@section('contenido1')

FORMATO DE CONTROL DE LIMPIEZA Y DESINFECCION EL GUALILO FREE ZONE

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSf5sBnpHgtlzi1JtW98lydJqGuct1EQpArKlsiYKj2Ci6Cilw/viewform" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
@endsection
