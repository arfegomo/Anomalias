@extends('master')

@section('titulo','Covid-19')

@section('contenido1')

Encuesta pago prima de servicios

@endsection

@section('contenido2')



<hr>

<div class="row">
	<div class="col-md-12" id="pdf">
<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdSrLVXFIteX_i4ogkIZLPIqo7kJg3knGD7rysS48inD79XYQ/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
</div>
</div>

@endsection



