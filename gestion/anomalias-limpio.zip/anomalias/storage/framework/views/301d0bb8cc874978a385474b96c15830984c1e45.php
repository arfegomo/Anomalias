<!DOCTYPE html>
<html>
<head>
	<title>Respueta nueva de anomalía.</title>
</head>
<body>
	<h1>Se ha creado una respuesta para la anomalía # <?php echo e($respuestas); ?> grupo <?php echo e($grupo); ?> </h1>
	<p>Por favor ingresa y valida!</p>
</body>
</html>