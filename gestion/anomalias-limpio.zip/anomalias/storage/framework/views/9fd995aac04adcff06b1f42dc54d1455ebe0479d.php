<?php $__env->startSection('titulo','Listado de grupos de productos'); ?>

<?php $__env->startSection('contenido1'); ?>

<b>Video tutoriales:</b>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido2'); ?>

<iframe src="https://onedrive.live.com/embed?cid=A57B276D990E0A71&resid=A57B276D990E0A71%217002&authkey=AI1X_W042ZHrslY" width="320" height="180" frameborder="0" scrolling="no" allowfullscreen></iframe>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>