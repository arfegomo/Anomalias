<?php $__env->startSection('titulo','Formato-9'); ?>

<?php $__env->startSection('contenido1'); ?>

CONTROL DE SELLOS

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido2'); ?>

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSebnwACONcSBmQ7B5yZy38sBrx5JnzWV5TjnR3eoK1KVR8aTw/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>