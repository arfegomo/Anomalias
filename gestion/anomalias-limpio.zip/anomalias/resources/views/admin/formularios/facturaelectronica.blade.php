@extends('master')

@section('titulo','Factura electronica')

@section('contenido1')

SOLICITUD FACTURA PERSONALIZADA

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdQb8-t6grhRWDMBNza_80saNTJwJqufsub0rGkWrUCuRDAnA/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection
