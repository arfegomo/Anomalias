@extends('master')
@section('titulo','Listado de grupos de productos')

@section('contenido1')

<b>Video tutoriales:</b>

@endsection

@section('contenido2')

<iframe src="https://onedrive.live.com/embed?cid=A57B276D990E0A71&resid=A57B276D990E0A71%217002&authkey=AI1X_W042ZHrslY" width="320" height="180" frameborder="0" scrolling="no" allowfullscreen></iframe>

@endsection