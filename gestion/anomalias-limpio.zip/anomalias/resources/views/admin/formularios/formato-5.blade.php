@extends('master')

@section('titulo','Formato-5')

@section('contenido1')

FORMATO DE CONTROL DE LIMPIEZA Y DESINFECCIÓN

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeR5yB8OefNipa-DniLPRXfU35Be2m7rEIqznSvwqGWNjA17Q/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>

@endsection
