@extends('master')

@section('titulo','Formato-8')

@section('contenido1')

CONTROL ENTREGA DE TARJETAS

@endsection

@section('contenido2')

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdrMnVKdIUzyvca9XUd_zYD4r48mODa0F1IQ_8sXau-y6AiLQ/viewform?embedded=true" width="1024" height="768" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe>
@endsection
